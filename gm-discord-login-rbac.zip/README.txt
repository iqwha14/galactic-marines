Discord Login + Rechte (kein Code mehr)

Du brauchst:
1) next-auth installieren:
   npm i next-auth

2) Discord OAuth App erstellen (Discord Developer Portal):
   - Redirect URL: https://DEINE-DOMAIN/api/auth/callback/discord
     (für lokal: http://localhost:3000/api/auth/callback/discord)

3) ENV Variablen (Vercel -> Project Settings -> Environment Variables):
   DISCORD_CLIENT_ID=...
   DISCORD_CLIENT_SECRET=...
   NEXTAUTH_SECRET=... (irgendein langes Secret)
   NEXTAUTH_URL=https://DEINE-DOMAIN   (auf Vercel meist automatisch ok, sonst setzen)

   // Rechte-Listen (Discord User IDs, komma-separiert)
   EDITOR_DISCORD_IDS=123,456
   UO_DISCORD_IDS=123,789

4) Dateien aus diesem ZIP ins Projekt kopieren/überschreiben:
   - auth.ts
   - app/api/auth/[...nextauth]/route.ts
   - app/api/trello/_lib/authz.ts
   - app/api/uo-doc/route.ts
   - app/api/trello/checkitem/route.ts
   - app/api/trello/promote/route.ts
   - app/page.tsx

UO Doc Fehler "Google Doc export failed":
- Das Google Doc muss "Jeder mit dem Link: Betrachter" sein.
- Private Docs kannst du nur per Google Drive API + Service Account exportieren.
