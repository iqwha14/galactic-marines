AUTH ORDNER (NextAuth) – Drop-in

Lege die Dateien exakt so ab:

/auth.ts
/app/api/auth/[...nextauth]/route.ts

WICHTIG:
- auth.ts liegt im Projekt-ROOT (gleiche Ebene wie package.json)
- der Ordner heißt genau: app/api/auth/[...nextauth]  (mit drei Punkten!)

ENV (Vercel -> Settings -> Environment Variables):
DISCORD_CLIENT_ID=...
DISCORD_CLIENT_SECRET=...
NEXTAUTH_SECRET=... (langes random)
NEXTAUTH_URL=https://DEINE-DOMAIN  (bei dir: https://galactic-marines.vercel.app)

Optional (Rechte):
EDITOR_DISCORD_IDS=123,456
UO_DISCORD_IDS=123,789

Discord Developer Portal:
OAuth2 Redirect URL muss enthalten:
https://galactic-marines.vercel.app/api/auth/callback/discord

Test:
https://galactic-marines.vercel.app/api/auth/providers
soll JSON liefern (nicht 404)
