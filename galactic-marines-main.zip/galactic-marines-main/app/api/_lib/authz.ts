// Wrapper so existing imports keep working.
export * from "@/lib/authz";
