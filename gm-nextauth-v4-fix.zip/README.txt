FIX für NextAuth "handlers undefined" (NextAuth v4 kompatibel)

Warum:
- In NextAuth v4 gibt es kein { handlers, auth } Return wie in v5.
- Deshalb war handlers undefined und Build ist kaputt.

Du ersetzt/fügst diese Dateien hinzu:

1) app/api/auth/[...nextauth]/options.ts   (neu)
2) app/api/auth/[...nextauth]/route.ts     (ersetzen)
3) app/api/_lib/authz.ts                   (ersetzen)

WICHTIG:
- auth.ts im Root wird NICHT mehr gebraucht (kannst du löschen oder ignorieren).

ENV (Vercel):
DISCORD_CLIENT_ID=...
DISCORD_CLIENT_SECRET=...
NEXTAUTH_SECRET=... (langes random)
NEXTAUTH_URL=https://galactic-marines.vercel.app

Rechte:
EDITOR_DISCORD_IDS=123,456
UO_DISCORD_IDS=123,789

Test:
https://galactic-marines.vercel.app/api/auth/providers  -> JSON (nicht 404)
